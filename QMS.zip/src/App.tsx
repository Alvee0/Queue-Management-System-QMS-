import QueueApp from './QueueApp'

function App() {
  return (
    <div>
      <QueueApp />
    </div>
  )
}

export default App