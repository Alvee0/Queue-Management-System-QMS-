import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Users,
  Monitor,
  Printer,
  Settings as SettingsIcon,
  BarChart3,
  Search,
  Plus,
  Play,
  Volume2,
  VolumeX,
  RotateCcw,
  CheckCircle,
  XCircle,
  Pause,
  ArrowRight,
  Sun,
  Moon,
  Clock,
  UserCheck,
  AlertTriangle,
  Award,
  Maximize2,
  Minimize2,
  Trash2,
  Edit,
  Download,
  Upload,
  RefreshCw,
  HelpCircle,
  Sliders,
  Bell,
  Check,
  ChevronRight,
  Building,
  Phone,
  FileText,
  Filter,
  Shield,
  Layers,
  QrCode
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend
} from 'recharts';

const PRIORITY_LEVELS = {
  NORMAL: { id: 'NORMAL', label: 'Normal', weight: 1, color: 'bg-slate-500 text-white', badge: 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200' },
  VIP: { id: 'VIP', label: 'VIP', weight: 10, color: 'bg-amber-500 text-white', badge: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300' },
  SENIOR: { id: 'SENIOR', label: 'Senior Citizen', weight: 5, color: 'bg-purple-500 text-white', badge: 'bg-purple-100 text-purple-800 dark:bg-purple-900/40 dark:text-purple-300' },
  PREGNANT: { id: 'PREGNANT', label: 'Pregnant', weight: 6, color: 'bg-pink-500 text-white', badge: 'bg-pink-100 text-pink-800 dark:bg-pink-900/40 dark:text-pink-300' },
  DISABLED: { id: 'DISABLED', label: 'Disabled', weight: 7, color: 'bg-blue-500 text-white', badge: 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300' },
  EMERGENCY: { id: 'EMERGENCY', label: 'Emergency', weight: 20, color: 'bg-red-600 text-white', badge: 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300' }
};

const TOKEN_STATUS = {
  WAITING: { id: 'WAITING', label: 'Waiting', color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-300 dark:border-amber-800' },
  CALLING: { id: 'CALLING', label: 'Calling', color: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-300 dark:border-blue-800' },
  SERVING: { id: 'SERVING', label: 'Serving', color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-300 dark:border-emerald-800' },
  HOLD: { id: 'HOLD', label: 'On Hold', color: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-300 dark:border-indigo-800' },
  COMPLETED: { id: 'COMPLETED', label: 'Completed', color: 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-800' },
  SKIPPED: { id: 'SKIPPED', label: 'Skipped', color: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-300 dark:border-orange-800' },
  CANCELLED: { id: 'CANCELLED', label: 'Cancelled', color: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-300 dark:border-red-800' }
};

const INITIAL_CATEGORIES = [
  { id: 'CAT-GEN', code: 'A', name: 'General Enquiries', prefix: 'A', estTime: 5, color: '#3b82f6' },
  { id: 'CAT-CSH', code: 'B', name: 'Cash & Payments', prefix: 'B', estTime: 3, color: '#10b981' },
  { id: 'CAT-ACCS', code: 'C', name: 'Accounts & Banking', prefix: 'C', estTime: 10, color: '#8b5cf6' },
  { id: 'CAT-SUPP', code: 'D', name: 'Technical Support', prefix: 'D', estTime: 8, color: '#f59e0b' }
];

const INITIAL_COUNTERS = [
  { id: 'CNT-01', number: 1, name: 'Counter 1', categoryIds: ['CAT-GEN', 'CAT-CSH'], active: true, staff: 'Sarah Connor', color: '#3b82f6' },
  { id: 'CNT-02', number: 2, name: 'Counter 2', categoryIds: ['CAT-GEN'], active: true, staff: 'John Doe', color: '#10b981' },
  { id: 'CNT-03', number: 3, name: 'Counter 3 - VIP', categoryIds: ['CAT-ACCS', 'CAT-SUPP'], active: true, staff: 'Alice Smith', color: '#8b5cf6' },
  { id: 'CNT-04', number: 4, name: 'Express Cash', categoryIds: ['CAT-CSH'], active: true, staff: 'Bob Johnson', color: '#f59e0b' }
];

const playOfflineSound = (type, volume = 0.8) => {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();

    const gainNode = ctx.createGain();
    gainNode.gain.value = volume;
    gainNode.connect(ctx.destination);

    const now = ctx.currentTime;

    if (type === 'CALL') {
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      osc1.type = 'sine';
      osc2.type = 'sine';

      osc1.frequency.setValueAtTime(783.99, now); // G5
      osc2.frequency.setValueAtTime(1046.50, now + 0.15); // C6

      osc1.connect(gainNode);
      osc2.connect(gainNode);

      osc1.start(now);
      osc1.stop(now + 0.15);
      osc2.start(now + 0.15);
      osc2.stop(now + 0.5);
    } else if (type === 'COMPLETE') {
      [523.25, 659.25, 783.99].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);
        osc.connect(gainNode);
        osc.start(now + idx * 0.08);
        osc.stop(now + (idx + 1) * 0.08 + 0.1);
      });
    } else if (type === 'CANCEL') {
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(150, now + 0.25);
      osc.connect(gainNode);
      osc.start(now);
      osc.stop(now + 0.25);
    }
  } catch (err) {
    console.warn('Audio synthesis not permitted without user interaction', err);
  }
};

const announceTokenVoice = (tokenNumber, counterName, lang = 'en-US', speed = 0.9, pitch = 1.0, isMuted = false) => {
  if (isMuted || !('speechSynthesis' in window)) return;

  window.speechSynthesis.cancel();

  const formattedToken = tokenNumber.replace(/([A-Z])(\d+)/, (match, p1, p2) => {
    return `${p1}, ${p2.split('').join(' ')}`;
  });

  const text = lang.startsWith('bn') 
    ? `টোকেন নম্বর ${formattedToken}, অনুগ্রহ করে ${counterName} এ আসুন`
    : `Token number ${formattedToken}, please proceed to ${counterName}`;

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = speed;
  utterance.pitch = pitch;
  utterance.lang = lang;

  const voices = window.speechSynthesis.getVoices();
  const matchedVoice = voices.find(v => v.lang.includes(lang.split('-')[0]));
  if (matchedVoice) utterance.voice = matchedVoice;

  window.speechSynthesis.speak(utterance);
};

const generateMockTokens = () => {
  const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
  const tokens = [];
  const categories = INITIAL_CATEGORIES;
  const statuses = [TOKEN_STATUS.COMPLETED.id, TOKEN_STATUS.COMPLETED.id, TOKEN_STATUS.COMPLETED.id, TOKEN_STATUS.WAITING.id, TOKEN_STATUS.SKIPPED.id];

  for (let i = 1; i <= 32; i++) {
    const cat = categories[i % categories.length];
    const seqStr = String(i).padStart(4, '0');
    const fullCode = `${cat.prefix}${seqStr}`;
    const fullId = `${today}-${fullCode}`;
    const status = i > 28 ? TOKEN_STATUS.WAITING.id : (i === 28 ? TOKEN_STATUS.SERVING.id : statuses[i % statuses.length]);
    const counterId = status === TOKEN_STATUS.WAITING.id ? null : INITIAL_COUNTERS[i % INITIAL_COUNTERS.length].id;
    const priorityKey = i % 7 === 0 ? 'VIP' : (i % 9 === 0 ? 'SENIOR' : 'NORMAL');

    tokens.push({
      id: fullId,
      number: fullCode,
      seq: i,
      date: new Date().toISOString().split('T')[0],
      categoryId: cat.id,
      categoryName: cat.name,
      priority: priorityKey,
      customerName: i % 3 === 0 ? `Customer #${i}` : '',
      customerPhone: i % 4 === 0 ? `+1 555-01${i}` : '',
      remarks: i % 5 === 0 ? 'Urgent request' : '',
      status: status,
      counterId: counterId,
      issuedAt: new Date(Date.now() - (35 - i) * 12 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      calledAt: status !== 'WAITING' ? new Date(Date.now() - (35 - i) * 10 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : null,
      completedAt: status === 'COMPLETED' ? new Date(Date.now() - (35 - i) * 5 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : null,
      waitTimeMinutes: Math.floor(Math.random() * 12) + 2,
      serveTimeMinutes: status === 'COMPLETED' ? Math.floor(Math.random() * 8) + 2 : null
    });
  }
  return tokens;
};

export default function App() {
  const [tokens, setTokens] = useState(() => {
    const saved = localStorage.getItem('EQMS_TOKENS');
    return saved ? JSON.parse(saved) : generateMockTokens();
  });

  const [counters, setCounters] = useState(() => {
    const saved = localStorage.getItem('EQMS_COUNTERS');
    return saved ? JSON.parse(saved) : INITIAL_COUNTERS;
  });

  const [categories, setCategories] = useState(() => {
    const saved = localStorage.getItem('EQMS_CATEGORIES');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [settings, setSettings] = useState(() => {
    const saved = localStorage.getItem('EQMS_SETTINGS');
    return saved ? JSON.parse(saved) : {
      businessName: 'Apex Global Customer Care',
      subtitle: 'Main Branch Operations Center',
      address: '742 Evergreen Terrace, Sector 4',
      phone: '+1 (800) 555-0199',
      theme: 'dark',
      soundEnabled: true,
      soundVolume: 0.8,
      voiceEnabled: true,
      voiceLang: 'en-US',
      voiceSpeed: 0.9,
      voicePitch: 1.0,
      autoPrintOnIssue: true,
      autoResetDaily: true,
      resetTime: '00:00',
      primaryColor: '#2563eb'
    };
  });

  const [activeTab, setActiveTab] = useState('DASHBOARD');
  const [activeWorkstationCounterId, setActiveWorkstationCounterId] = useState(INITIAL_COUNTERS[0].id);
  const [selectedTokenForPrint, setSelectedTokenForPrint] = useState(null);
  const [toastNotification, setToastNotification] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [shortcutHelpOpen, setShortcutHelpOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Counter Modal State
  const [isCounterModalOpen, setIsCounterModalOpen] = useState(false);
  const [editingCounter, setEditingCounter] = useState(null);
  const [counterForm, setCounterForm] = useState({
    name: '',
    staff: '',
    active: true,
    categoryIds: [],
    color: '#3b82f6'
  });

  useEffect(() => {
    localStorage.setItem('EQMS_TOKENS', JSON.stringify(tokens));
  }, [tokens]);

  useEffect(() => {
    localStorage.setItem('EQMS_COUNTERS', JSON.stringify(counters));
  }, [counters]);

  useEffect(() => {
    localStorage.setItem('EQMS_CATEGORIES', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('EQMS_SETTINGS', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const showToast = (message, type = 'info') => {
    setToastNotification({ message, type, id: Date.now() });
    setTimeout(() => setToastNotification(null), 3500);
  };

  const handlePrintTicket = () => {
    window.print();
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;

      if (e.key === 'F1') {
        e.preventDefault();
        setActiveTab('RECEPTION');
      } else if (e.key === 'F2') {
        e.preventDefault();
        setActiveTab('WORKSTATION');
        handleCallNextToken(activeWorkstationCounterId);
      } else if (e.key === 'F3') {
        e.preventDefault();
        setActiveTab('WORKSTATION');
        handleRecallCurrentToken(activeWorkstationCounterId);
      } else if (e.key === 'F4') {
        e.preventDefault();
        setActiveTab('WORKSTATION');
        handleSkipCurrentToken(activeWorkstationCounterId);
      } else if (e.key === 'F5') {
        e.preventDefault();
        setActiveTab('WORKSTATION');
        handleCompleteCurrentToken(activeWorkstationCounterId);
      } else if (e.key === 'F11') {
        e.preventDefault();
        setActiveTab('TV_DISPLAY');
      } else if (e.ctrlKey && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        if (selectedTokenForPrint) handlePrintTicket();
      } else if (e.ctrlKey && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        setActiveTab('SEARCH');
      } else if (e.ctrlKey && e.key.toLowerCase() === 's') {
        e.preventDefault();
        setActiveTab('SETTINGS');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeWorkstationCounterId, tokens, counters, selectedTokenForPrint]);

  const handleGenerateToken = (categoryId, priority = 'NORMAL', customerName = '', customerPhone = '', remarks = '') => {
    const category = categories.find(c => c.id === categoryId) || categories[0];
    const todayStr = new Date().toISOString().split('T')[0].replace(/-/g, '');
    
    const categoryTokens = tokens.filter(t => t.categoryId === category.id);
    const nextSeq = categoryTokens.length + 1;
    const seqCode = String(nextSeq).padStart(4, '0');
    const tokenNumber = `${category.prefix}${seqCode}`;
    const fullId = `${todayStr}-${tokenNumber}`;

    const newToken = {
      id: fullId,
      number: tokenNumber,
      seq: nextSeq,
      date: new Date().toISOString().split('T')[0],
      categoryId: category.id,
      categoryName: category.name,
      priority: priority,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      remarks: remarks.trim(),
      status: TOKEN_STATUS.WAITING.id,
      counterId: null,
      issuedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      calledAt: null,
      completedAt: null,
      waitTimeMinutes: 0,
      serveTimeMinutes: 0
    };

    setTokens(prev => [newToken, ...prev]);
    setSelectedTokenForPrint(newToken);

    if (settings.soundEnabled) playOfflineSound('COMPLETE', settings.soundVolume);
    showToast(`Token ${tokenNumber} generated successfully!`, 'success');

    if (settings.autoPrintOnIssue) {
      setTimeout(() => {
        window.print();
      }, 300);
    }

    return newToken;
  };

  const handleCallNextToken = (counterId) => {
    const counter = counters.find(c => c.id === counterId);
    if (!counter || !counter.active) {
      showToast('Selected counter is inactive or unavailable.', 'error');
      return;
    }

    const waitingTokens = tokens.filter(t => 
      t.status === TOKEN_STATUS.WAITING.id && 
      (counter.categoryIds.length === 0 || counter.categoryIds.includes(t.categoryId))
    );

    if (waitingTokens.length === 0) {
      showToast(`No waiting customers for ${counter.name}`, 'warning');
      return;
    }

    const sortedWaiting = [...waitingTokens].sort((a, b) => {
      const weightA = PRIORITY_LEVELS[a.priority]?.weight || 1;
      const weightB = PRIORITY_LEVELS[b.priority]?.weight || 1;
      if (weightB !== weightA) return weightB - weightA;
      return a.seq - b.seq;
    });

    const targetToken = sortedWaiting[0];

    const updatedTokens = tokens.map(t => {
      if (t.counterId === counterId && (t.status === TOKEN_STATUS.CALLING.id || t.status === TOKEN_STATUS.SERVING.id)) {
        return {
          ...t,
          status: TOKEN_STATUS.COMPLETED.id,
          completedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
      }
      if (t.id === targetToken.id) {
        return {
          ...t,
          status: TOKEN_STATUS.CALLING.id,
          counterId: counterId,
          calledAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
      }
      return t;
    });

    setTokens(updatedTokens);

    if (settings.soundEnabled) playOfflineSound('CALL', settings.soundVolume);
    if (settings.voiceEnabled) {
      announceTokenVoice(
        targetToken.number,
        counter.name,
        settings.voiceLang,
        settings.voiceSpeed,
        settings.voicePitch,
        !settings.voiceEnabled
      );
    }

    showToast(`Calling ${targetToken.number} to ${counter.name}`, 'info');
  };

  const handleRecallCurrentToken = (counterId) => {
    const counter = counters.find(c => c.id === counterId);
    const activeToken = tokens.find(t => t.counterId === counterId && (t.status === TOKEN_STATUS.CALLING.id || t.status === TOKEN_STATUS.SERVING.id));

    if (!activeToken) {
      showToast('No active token on this counter to recall.', 'warning');
      return;
    }

    if (settings.soundEnabled) playOfflineSound('CALL', settings.soundVolume);
    if (settings.voiceEnabled && counter) {
      announceTokenVoice(
        activeToken.number,
        counter.name,
        settings.voiceLang,
        settings.voiceSpeed,
        settings.voicePitch,
        !settings.voiceEnabled
      );
    }

    showToast(`Recalled token ${activeToken.number}`, 'info');
  };

  const handleCompleteCurrentToken = (counterId) => {
    const activeToken = tokens.find(t => t.counterId === counterId && (t.status === TOKEN_STATUS.CALLING.id || t.status === TOKEN_STATUS.SERVING.id));

    if (!activeToken) {
      showToast('No active token on this counter to complete.', 'warning');
      return;
    }

    setTokens(prev => prev.map(t => t.id === activeToken.id ? {
      ...t,
      status: TOKEN_STATUS.COMPLETED.id,
      completedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    } : t));

    if (settings.soundEnabled) playOfflineSound('COMPLETE', settings.soundVolume);
    showToast(`Token ${activeToken.number} marked as completed.`, 'success');
  };

  const handleSkipCurrentToken = (counterId) => {
    const activeToken = tokens.find(t => t.counterId === counterId && (t.status === TOKEN_STATUS.CALLING.id || t.status === TOKEN_STATUS.SERVING.id));

    if (!activeToken) {
      showToast('No active token to skip.', 'warning');
      return;
    }

    setTokens(prev => prev.map(t => t.id === activeToken.id ? {
      ...t,
      status: TOKEN_STATUS.SKIPPED.id
    } : t));

    showToast(`Token ${activeToken.number} skipped.`, 'warning');
  };

  const handleResumeHeldToken = (tokenId) => {
    setTokens(prev => prev.map(t => t.id === tokenId ? {
      ...t,
      status: TOKEN_STATUS.WAITING.id
    } : t));
    showToast('Token moved back to waiting queue.', 'info');
  };

  const handleCancelToken = (tokenId) => {
    setTokens(prev => prev.map(t => t.id === tokenId ? {
      ...t,
      status: TOKEN_STATUS.CANCELLED.id
    } : t));
    if (settings.soundEnabled) playOfflineSound('CANCEL', settings.soundVolume);
    showToast('Token cancelled.', 'error');
  };

  const handleDailyReset = () => {
    if (window.confirm('Are you sure you want to perform a daily reset? Current token queue numbers will reset.')) {
      setTokens([]);
      showToast('System queue reset completed for today.', 'success');
    }
  };

  const handleOpenAddCounterModal = () => {
    setEditingCounter(null);
    setCounterForm({
      name: `Counter ${counters.length + 1}`,
      staff: '',
      active: true,
      categoryIds: categories.map(c => c.id),
      color: '#3b82f6'
    });
    setIsCounterModalOpen(true);
  };

  const handleOpenEditCounterModal = (counter) => {
    setEditingCounter(counter);
    setCounterForm({
      name: counter.name,
      staff: counter.staff || '',
      active: counter.active,
      categoryIds: counter.categoryIds || [],
      color: counter.color || '#3b82f6'
    });
    setIsCounterModalOpen(true);
  };

  const handleSaveCounter = (e) => {
    e.preventDefault();
    if (!counterForm.name.trim()) {
      showToast('Counter name cannot be empty.', 'warning');
      return;
    }

    if (editingCounter) {
      setCounters(prev => prev.map(c => c.id === editingCounter.id ? {
        ...c,
        name: counterForm.name.trim(),
        staff: counterForm.staff.trim() || 'Unassigned',
        active: counterForm.active,
        categoryIds: counterForm.categoryIds,
        color: counterForm.color
      } : c));
      showToast(`Counter "${counterForm.name}" updated!`, 'success');
    } else {
      const newNumber = counters.length > 0 ? Math.max(...counters.map(c => c.number || 0)) + 1 : 1;
      const newCounter = {
        id: `CNT-${String(newNumber).padStart(2, '0')}`,
        number: newNumber,
        name: counterForm.name.trim(),
        categoryIds: counterForm.categoryIds,
        active: counterForm.active,
        staff: counterForm.staff.trim() || 'Unassigned',
        color: counterForm.color
      };
      setCounters(prev => [...prev, newCounter]);
      showToast(`Counter "${newCounter.name}" added successfully!`, 'success');
    }

    setIsCounterModalOpen(false);
  };

  const handleDeleteCounter = (counterId) => {
    if (counters.length <= 1) {
      showToast('System requires at least one counter.', 'warning');
      return;
    }
    const target = counters.find(c => c.id === counterId);
    if (window.confirm(`Are you sure you want to delete ${target?.name || 'this counter'}?`)) {
      setCounters(prev => prev.filter(c => c.id !== counterId));
      if (activeWorkstationCounterId === counterId) {
        const remaining = counters.filter(c => c.id !== counterId);
        if (remaining.length > 0) setActiveWorkstationCounterId(remaining[0].id);
      }
      showToast('Counter deleted.', 'info');
    }
  };

  const handleToggleCounterActive = (counterId) => {
    setCounters(prev => prev.map(c => {
      if (c.id === counterId) {
        const updated = !c.active;
        showToast(`${c.name} is now ${updated ? 'Online' : 'Offline'}.`, updated ? 'success' : 'warning');
        return { ...c, active: updated };
      }
      return c;
    }));
  };

  const stats = useMemo(() => {
    const total = tokens.length;
    const waiting = tokens.filter(t => t.status === TOKEN_STATUS.WAITING.id).length;
    const serving = tokens.filter(t => t.status === TOKEN_STATUS.CALLING.id || t.status === TOKEN_STATUS.SERVING.id).length;
    const completed = tokens.filter(t => t.status === TOKEN_STATUS.COMPLETED.id).length;
    const skipped = tokens.filter(t => t.status === TOKEN_STATUS.SKIPPED.id).length;
    const cancelled = tokens.filter(t => t.status === TOKEN_STATUS.CANCELLED.id).length;
    const onHold = tokens.filter(t => t.status === TOKEN_STATUS.HOLD.id).length;

    const avgWait = tokens.length ? Math.round(tokens.reduce((acc, t) => acc + (t.waitTimeMinutes || 5), 0) / tokens.length) : 0;
    const avgServe = completed ? Math.round(tokens.filter(t => t.status === TOKEN_STATUS.COMPLETED.id).reduce((acc, t) => acc + (t.serveTimeMinutes || 4), 0) / completed) : 0;

    return { total, waiting, serving, completed, skipped, cancelled, onHold, avgWait, avgServe };
  }, [tokens]);

  const categoryDistributionData = useMemo(() => {
    return categories.map(cat => ({
      name: cat.name,
      value: tokens.filter(t => t.categoryId === cat.id).length,
      color: cat.color
    }));
  }, [categories, tokens]);

  const counterPerformanceData = useMemo(() => {
    return counters.map(cnt => ({
      name: cnt.name,
      completed: tokens.filter(t => t.counterId === cnt.id && t.status === TOKEN_STATUS.COMPLETED.id).length,
      skipped: tokens.filter(t => t.counterId === cnt.id && t.status === TOKEN_STATUS.SKIPPED.id).length
    }));
  }, [counters, tokens]);

  const hourlyFlowData = [
    { hour: '08:00', tokens: 12 },
    { hour: '09:00', tokens: 28 },
    { hour: '10:00', tokens: 45 },
    { hour: '11:00', tokens: 60 },
    { hour: '12:00', tokens: 38 },
    { hour: '13:00', tokens: 25 },
    { hour: '14:00', tokens: 52 },
    { hour: '15:00', tokens: 40 },
    { hour: '16:00', tokens: 22 }
  ];

  const exportTokensCSV = () => {
    const headers = ['Token Number', 'Category', 'Priority', 'Customer', 'Phone', 'Status', 'Issued Time', 'Called Time', 'Completed Time'];
    const rows = tokens.map(t => [
      t.number,
      t.categoryName,
      t.priority,
      t.customerName || 'N/A',
      t.customerPhone || 'N/A',
      t.status,
      t.issuedAt || '',
      t.calledAt || '',
      t.completedAt || ''
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `queue_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('CSV Report downloaded successfully!', 'success');
  };

  const exportSystemJSON = () => {
    const backupData = {
      tokens,
      counters,
      categories,
      settings,
      exportDate: new Date().toISOString()
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `eqms_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Full system backup exported!', 'success');
  };

  const importSystemJSON = (event) => {
    const fileReader = new FileReader();
    if (event.target.files && event.target.files[0]) {
      fileReader.readAsText(event.target.files[0], 'UTF-8');
      fileReader.onload = (e) => {
        try {
          const parsed = JSON.parse(e.target.result);
          if (parsed.tokens && parsed.counters && parsed.categories) {
            setTokens(parsed.tokens);
            setCounters(parsed.counters);
            setCategories(parsed.categories);
            if (parsed.settings) setSettings(parsed.settings);
            showToast('Backup restored successfully!', 'success');
          } else {
            showToast('Invalid backup file format.', 'error');
          }
        } catch (err) {
          showToast('Failed to parse backup JSON.', 'error');
        }
      };
    }
  };

  // Compute queue context stats for printing
  const getTicketQueueContext = (token) => {
    if (!token) return { waitingAhead: 0, estTime: 5 };
    const cat = categories.find(c => c.id === token.categoryId);
    const catEstTime = cat ? cat.estTime : 5;
    const waitingAhead = tokens.filter(t => t.categoryId === token.categoryId && t.status === TOKEN_STATUS.WAITING.id && t.seq < token.seq).length;
    return {
      waitingAhead,
      estTime: Math.max(catEstTime, waitingAhead * catEstTime)
    };
  };

  const renderHeader = () => (
    <header className="bg-slate-900 border-b border-slate-800 text-white px-6 py-3 flex items-center justify-between sticky top-0 z-40 shadow-lg print:hidden">
      <div className="flex items-center space-x-4">
        <div className="bg-blue-600 p-2 rounded-xl text-white shadow-md shadow-blue-500/20">
          <Building className="w-6 h-6" />
        </div>
        <div>
          <h1 className="font-bold text-lg tracking-tight flex items-center gap-2">
            {settings.businessName}
            <span className="text-xs bg-blue-500/20 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded-full font-mono">
              OFFLINE ENTERPRISE
            </span>
          </h1>
          <p className="text-xs text-slate-400">{settings.subtitle}</p>
        </div>
      </div>

      <nav className="hidden lg:flex items-center bg-slate-800/80 p-1 rounded-xl border border-slate-700/60">
        {[
          { id: 'DASHBOARD', label: 'Dashboard', icon: BarChart3 },
          { id: 'RECEPTION', label: 'Reception & Issue', icon: Plus },
          { id: 'WORKSTATION', label: 'Counter Station', icon: Users },
          { id: 'TV_DISPLAY', label: 'TV Display Screen', icon: Monitor },
          { id: 'SEARCH', label: 'Token Manager', icon: Search },
          { id: 'REPORTS', label: 'Reports', icon: FileText },
          { id: 'SETTINGS', label: 'Settings', icon: SettingsIcon }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="flex items-center space-x-3">
        <button
          onClick={() => setSettings(s => ({ ...s, soundEnabled: !s.soundEnabled }))}
          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
          title={settings.soundEnabled ? 'Mute Audio' : 'Unmute Audio'}
        >
          {settings.soundEnabled ? <Volume2 className="w-5 h-5 text-emerald-400" /> : <VolumeX className="w-5 h-5 text-slate-500" />}
        </button>

        <button
          onClick={() => setShortcutHelpOpen(true)}
          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
          title="Keyboard Shortcuts"
        >
          <HelpCircle className="w-5 h-5" />
        </button>

        <div className="text-right border-l border-slate-800 pl-3 hidden sm:block">
          <div className="text-xs font-mono font-semibold text-slate-200">
            {currentTime.toLocaleTimeString()}
          </div>
          <div className="text-[10px] text-slate-400">
            {currentTime.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}
          </div>
        </div>
      </div>
    </header>
  );

  const renderMobileNav = () => (
    <div className="lg:hidden bg-slate-900 border-b border-slate-800 px-4 py-2 overflow-x-auto flex space-x-2 print:hidden">
      {[
        { id: 'DASHBOARD', label: 'Dashboard', icon: BarChart3 },
        { id: 'RECEPTION', label: 'Reception', icon: Plus },
        { id: 'WORKSTATION', label: 'Counter', icon: Users },
        { id: 'TV_DISPLAY', label: 'TV Screen', icon: Monitor },
        { id: 'SEARCH', label: 'Tokens', icon: Search },
        { id: 'REPORTS', label: 'Reports', icon: FileText },
        { id: 'SETTINGS', label: 'Settings', icon: SettingsIcon }
      ].map((tab) => {
        const Icon = tab.icon;
        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs whitespace-nowrap ${
              activeTab === tab.id ? 'bg-blue-600 text-white' : 'text-slate-400 bg-slate-800'
            }`}
          >
            <Icon className="w-3.5 h-3.5" />
            <span>{tab.label}</span>
          </button>
        );
      })}
    </div>
  );

  const renderDashboard = () => (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-800/60 border border-slate-700/60 p-4 rounded-2xl shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Total Tokens Today</span>
            <div className="p-2 bg-blue-500/10 text-blue-400 rounded-xl"><Layers className="w-5 h-5" /></div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-white">{stats.total}</span>
            <span className="text-xs text-emerald-400 font-medium">100% Active</span>
          </div>
        </div>

        <div className="bg-slate-800/60 border border-amber-500/30 p-4 rounded-2xl shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-amber-400 uppercase tracking-wider">Waiting Queue</span>
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl"><Clock className="w-5 h-5" /></div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-amber-400">{stats.waiting}</span>
            <span className="text-xs text-slate-400">Avg {stats.avgWait} mins wait</span>
          </div>
        </div>

        <div className="bg-slate-800/60 border border-emerald-500/30 p-4 rounded-2xl shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-400 uppercase tracking-wider">Currently Serving</span>
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl"><UserCheck className="w-5 h-5" /></div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-emerald-400">{stats.serving}</span>
            <span className="text-xs text-slate-400">{counters.filter(c => c.active).length} Counters Active</span>
          </div>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/60 p-4 rounded-2xl shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Completed</span>
            <div className="p-2 bg-slate-700/50 text-slate-300 rounded-xl"><CheckCircle className="w-5 h-5" /></div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-white">{stats.completed}</span>
            <span className="text-xs text-slate-400">Avg {stats.avgServe} mins serve</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-800/60 border border-slate-700/60 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-blue-400" />
              Hourly Customer Flow Traffic
            </h3>
            <span className="text-xs text-slate-400">Realtime distribution</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={hourlyFlowData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="hour" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }}
                />
                <Bar dataKey="tokens" fill="#3b82f6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-5 shadow-sm">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
            <Layers className="w-4 h-4 text-purple-400" />
            Service Distribution
          </h3>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryDistributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-2">
            {categoryDistributionData.map(cat => (
              <div key={cat.name} className="flex items-center space-x-2 text-xs">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: cat.color }}></span>
                <span className="text-slate-300 truncate">{cat.name}</span>
                <span className="text-slate-400 font-mono">({cat.value})</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-400" />
            Active Service Counters ({counters.length})
          </h3>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleOpenAddCounterModal}
              className="text-xs bg-blue-600 hover:bg-blue-500 text-white font-medium px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Counter</span>
            </button>
            <button 
              onClick={() => setActiveTab('WORKSTATION')}
              className="text-xs text-blue-400 hover:underline flex items-center gap-1"
            >
              Manage Counters <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {counters.map(cnt => {
            const activeToken = tokens.find(t => t.counterId === cnt.id && (t.status === TOKEN_STATUS.CALLING.id || t.status === TOKEN_STATUS.SERVING.id));
            return (
              <div 
                key={cnt.id}
                className={`p-4 rounded-xl border transition ${
                  cnt.active 
                    ? 'bg-slate-800 border-slate-700/80 hover:border-slate-600' 
                    : 'bg-slate-900/40 border-slate-800 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-sm">{cnt.name}</span>
                  <span className={`w-2.5 h-2.5 rounded-full ${cnt.active ? 'bg-emerald-500 animate-pulse' : 'bg-slate-600'}`}></span>
                </div>
                <div className="text-xs text-slate-400 mt-1">Staff: {cnt.staff || 'Unassigned'}</div>

                <div className="mt-4 pt-3 border-t border-slate-700/50 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Current Serving:</span>
                  {activeToken ? (
                    <span className="text-lg font-black font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                      {activeToken.number}
                    </span>
                  ) : (
                    <span className="text-xs text-slate-500 font-mono">IDLE</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  const [selectedCatId, setSelectedCatId] = useState(INITIAL_CATEGORIES[0].id);
  const [selectedPriority, setSelectedPriority] = useState('NORMAL');
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custRemarks, setCustRemarks] = useState('');

  const renderThermalReceiptElement = (token) => {
    if (!token) return null;
    const ctxStats = getTicketQueueContext(token);

    return (
      <div id="printable-ticket" className="bg-white text-black p-5 rounded-xl shadow-2xl border border-slate-300 font-mono max-w-[280px] mx-auto text-center space-y-3 print:border-none print:shadow-none print:max-w-none print:w-full">
        {/* Header Branding */}
        <div className="border-b-2 border-dashed border-black pb-3">
          <h4 className="font-black text-base uppercase tracking-tight leading-tight">{settings.businessName}</h4>
          <p className="text-[10px] text-slate-700 mt-0.5">{settings.subtitle}</p>
          {settings.address && <p className="text-[9px] text-slate-600 mt-0.5">{settings.address}</p>}
          {settings.phone && <p className="text-[9px] text-slate-600">Tel: {settings.phone}</p>}
        </div>

        {/* Big Ticket Number */}
        <div className="py-1">
          <p className="text-xs text-slate-800 uppercase font-extrabold tracking-wider">{token.categoryName}</p>
          <div className="text-5xl font-black my-2 tracking-tight text-black border-y-2 border-black py-2">
            {token.number}
          </div>
          <div className="inline-block bg-black text-white px-3 py-0.5 rounded-full text-xs font-black uppercase">
            {token.priority} PRIORITY
          </div>
        </div>

        {/* Queue Context Stats */}
        <div className="bg-slate-100 p-2.5 rounded border border-slate-300 text-xs text-left space-y-1">
          <div className="flex justify-between text-slate-800">
            <span>Waiting Ahead:</span>
            <span className="font-bold">{ctxStats.waitingAhead} customers</span>
          </div>
          <div className="flex justify-between text-slate-800">
            <span>Est. Wait Time:</span>
            <span className="font-bold">~{ctxStats.estTime} mins</span>
          </div>
        </div>

        {/* Optional Customer Details */}
        {token.customerName && (
          <div className="text-left text-xs bg-slate-50 p-2 rounded border border-slate-200">
            <div><strong>Name:</strong> {token.customerName}</div>
            {token.customerPhone && <div><strong>Phone:</strong> {token.customerPhone}</div>}
            {token.remarks && <div><strong>Note:</strong> {token.remarks}</div>}
          </div>
        )}

        {/* Timestamps */}
        <div className="text-[11px] text-slate-700 space-y-0.5 pt-1 border-t border-slate-300">
          <div className="flex justify-between">
            <span>Date:</span>
            <span>{token.date}</span>
          </div>
          <div className="flex justify-between">
            <span>Issued Time:</span>
            <span>{token.issuedAt}</span>
          </div>
        </div>

        {/* Simulated Barcode */}
        <div className="pt-2 flex flex-col items-center justify-center">
          <svg className="w-48 h-10 mx-auto" viewBox="0 0 200 40">
            <rect x="0" y="0" width="200" height="40" fill="white" />
            {[5, 12, 18, 22, 30, 35, 42, 50, 58, 62, 70, 78, 85, 92, 100, 108, 115, 122, 130, 138, 145, 155, 162, 170, 180, 190].map((x, idx) => (
              <rect key={idx} x={x} y="5" width={idx % 3 === 0 ? "4" : "2"} height="30" fill="black" />
            ))}
          </svg>
          <span className="text-[9px] text-slate-600 font-mono tracking-widest mt-0.5">{token.id}</span>
        </div>

        {/* Ticket Footer */}
        <div className="border-t-2 border-dashed border-black pt-2 text-[10px] text-slate-700 space-y-1">
          <p className="font-bold">Please watch the TV display screen for your number.</p>
          <p className="text-[9px] text-slate-500">Thank you for your visit!</p>
        </div>
      </div>
    );
  };

  const renderReception = () => (
    <div className="p-6 max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 print:p-0">
      <div className="lg:col-span-7 bg-slate-800/60 border border-slate-700/60 rounded-2xl p-6 shadow-xl space-y-6 print:hidden">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Plus className="w-5 h-5 text-blue-400" />
            Issue New Token Ticket
          </h2>
          <p className="text-xs text-slate-400 mt-1">Select service category and customer priority to generate a token.</p>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-semibold uppercase text-slate-400 tracking-wider">Select Service Category *</label>
          <div className="grid grid-cols-2 gap-3">
            {categories.map(cat => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCatId(cat.id)}
                className={`p-3.5 rounded-xl border text-left flex items-start space-x-3 transition ${
                  selectedCatId === cat.id
                    ? 'bg-blue-600/20 border-blue-500 text-white shadow-md'
                    : 'bg-slate-900/60 border-slate-700/60 text-slate-300 hover:border-slate-600'
                }`}
              >
                <div className="w-3 h-3 rounded-full mt-1 shrink-0" style={{ backgroundColor: cat.color }}></div>
                <div>
                  <div className="font-semibold text-sm">{cat.name}</div>
                  <div className="text-[11px] text-slate-400">Prefix: {cat.prefix} | Est: {cat.estTime}m</div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-semibold uppercase text-slate-400 tracking-wider">Priority Handling *</label>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {Object.values(PRIORITY_LEVELS).map(p => (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedPriority(p.id)}
                className={`py-2 px-2 rounded-xl text-xs font-medium border text-center transition ${
                  selectedPriority === p.id
                    ? 'bg-slate-700 border-blue-400 text-white shadow'
                    : 'bg-slate-900/60 border-slate-700/60 text-slate-400 hover:text-slate-200'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3 pt-2 border-t border-slate-700/50">
          <span className="text-xs font-semibold uppercase text-slate-400 tracking-wider">Optional Customer Info</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Customer Name"
              value={custName}
              onChange={e => setCustName(e.target.value)}
              className="bg-slate-900/80 border border-slate-700/80 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <input
              type="text"
              placeholder="Phone Number"
              value={custPhone}
              onChange={e => setCustPhone(e.target.value)}
              className="bg-slate-900/80 border border-slate-700/80 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>
          <input
            type="text"
            placeholder="Remarks or special notes..."
            value={custRemarks}
            onChange={e => setCustRemarks(e.target.value)}
            className="w-full bg-slate-900/80 border border-slate-700/80 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="pt-2 flex items-center justify-between">
          <label className="flex items-center space-x-2 text-xs text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={settings.autoPrintOnIssue}
              onChange={e => setSettings({ ...settings, autoPrintOnIssue: e.target.checked })}
              className="rounded border-slate-700 text-blue-600 focus:ring-0"
            />
            <span>Auto-trigger print dialog upon token generation</span>
          </label>
        </div>

        <button
          onClick={() => {
            handleGenerateToken(selectedCatId, selectedPriority, custName, custPhone, custRemarks);
            setCustName('');
            setCustPhone('');
            setCustRemarks('');
          }}
          className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-blue-500/25 flex items-center justify-center space-x-2 transition transform active:scale-95"
        >
          <Printer className="w-5 h-5" />
          <span>Generate & Print Token (F1)</span>
        </button>
      </div>

      <div className="lg:col-span-5 flex flex-col justify-between print:w-full print:col-span-12">
        <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-6 shadow-xl print:bg-transparent print:border-none print:p-0">
          <h3 className="text-sm font-semibold text-slate-300 mb-4 flex items-center justify-between print:hidden">
            <span>Thermal Ticket Print Preview</span>
            <span className="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded font-mono">58mm / 80mm Printer</span>
          </h3>

          {selectedTokenForPrint ? (
            renderThermalReceiptElement(selectedTokenForPrint)
          ) : (
            <div className="h-64 flex flex-col items-center justify-center text-slate-500 border-2 border-dashed border-slate-700 rounded-xl p-6 text-center print:hidden">
              <Printer className="w-10 h-10 mb-2 opacity-40" />
              <p className="text-xs">No token generated yet.</p>
              <p className="text-[11px] text-slate-600 mt-1">Select category and click generate to view ticket preview.</p>
            </div>
          )}

          {selectedTokenForPrint && (
            <div className="mt-4 space-y-2 print:hidden">
              <button
                onClick={handlePrintTicket}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 transition shadow-lg shadow-emerald-600/20"
              >
                <Printer className="w-4 h-4" />
                <span>Print Ticket Slip Now (Ctrl + P)</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderWorkstation = () => {
    const currentCounter = counters.find(c => c.id === activeWorkstationCounterId) || counters[0];
    const activeServingToken = tokens.find(t => t.counterId === currentCounter.id && (t.status === TOKEN_STATUS.CALLING.id || t.status === TOKEN_STATUS.SERVING.id));
    
    const waitingList = tokens.filter(t => 
      t.status === TOKEN_STATUS.WAITING.id && 
      (currentCounter.categoryIds.length === 0 || currentCounter.categoryIds.includes(t.categoryId))
    ).sort((a, b) => (PRIORITY_LEVELS[b.priority]?.weight || 1) - (PRIORITY_LEVELS[a.priority]?.weight || 1));

    const onHoldList = tokens.filter(t => t.status === TOKEN_STATUS.HOLD.id);

    return (
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        <div className="bg-slate-800/60 border border-slate-700/60 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Active Station:</span>
            <select
              value={activeWorkstationCounterId}
              onChange={e => setActiveWorkstationCounterId(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-1.5 text-sm font-bold focus:outline-none focus:border-blue-500"
            >
              {counters.map(cnt => (
                <option key={cnt.id} value={cnt.id}>{cnt.name} ({cnt.staff || 'Unstaffed'})</option>
              ))}
            </select>
          </div>

          <div className="flex items-center space-x-2">
            <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${
              currentCounter.active 
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                : 'bg-red-500/10 text-red-400 border-red-500/30'
            }`}>
              {currentCounter.active ? 'Counter Online' : 'Counter Offline'}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-slate-800/60 border border-slate-700/60 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Currently Serving Customer</span>
                <span className="text-xs font-mono text-slate-500">Counter ID: {currentCounter.id}</span>
              </div>

              {activeServingToken ? (
                <div className="my-6 text-center bg-slate-900/80 border border-slate-700 p-8 rounded-2xl relative overflow-hidden">
                  <div className="text-xs text-blue-400 font-semibold tracking-widest uppercase mb-1">{activeServingToken.categoryName}</div>
                  <div className="text-6xl font-black font-mono text-white tracking-tight animate-pulse">
                    {activeServingToken.number}
                  </div>

                  <div className="mt-4 flex items-center justify-center space-x-2">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${PRIORITY_LEVELS[activeServingToken.priority]?.color}`}>
                      {activeServingToken.priority}
                    </span>
                    <span className="text-xs text-slate-400">Called at {activeServingToken.calledAt}</span>
                  </div>

                  {activeServingToken.customerName && (
                    <div className="mt-4 text-xs text-slate-300 border-t border-slate-800 pt-3">
                      Customer: <strong>{activeServingToken.customerName}</strong> {activeServingToken.customerPhone && `(${activeServingToken.customerPhone})`}
                    </div>
                  )}
                </div>
              ) : (
                <div className="my-6 text-center bg-slate-900/30 border-2 border-dashed border-slate-700/60 p-12 rounded-2xl">
                  <Users className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                  <p className="text-slate-400 text-sm font-medium">Counter is idle.</p>
                  <p className="text-xs text-slate-500 mt-1">Press "Call Next Customer" or F2 to serve next ticket.</p>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-700/60">
              <button
                onClick={() => handleCallNextToken(currentCounter.id)}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-3 rounded-xl shadow-lg shadow-emerald-600/20 text-xs flex flex-col items-center justify-center space-y-1 transition transform active:scale-95"
              >
                <Play className="w-4 h-4" />
                <span>Call Next (F2)</span>
              </button>

              <button
                onClick={() => handleRecallCurrentToken(currentCounter.id)}
                disabled={!activeServingToken}
                className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold py-3 px-3 rounded-xl text-xs flex flex-col items-center justify-center space-y-1 transition"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Recall (F3)</span>
              </button>

              <button
                onClick={() => handleCompleteCurrentToken(currentCounter.id)}
                disabled={!activeServingToken}
                className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold py-3 px-3 rounded-xl text-xs flex flex-col items-center justify-center space-y-1 transition"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Complete (F5)</span>
              </button>

              <button
                onClick={() => handleSkipCurrentToken(currentCounter.id)}
                disabled={!activeServingToken}
                className="bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-bold py-3 px-3 rounded-xl text-xs flex flex-col items-center justify-center space-y-1 transition"
              >
                <XCircle className="w-4 h-4" />
                <span>Skip (F4)</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 bg-slate-800/60 border border-slate-700/60 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-white text-sm flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  Eligible Waiting Queue ({waitingList.length})
                </h3>
              </div>

              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {waitingList.length > 0 ? (
                  waitingList.map((token, idx) => (
                    <div
                      key={token.id}
                      className="bg-slate-900/80 border border-slate-700/80 p-3 rounded-xl flex items-center justify-between"
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-xs font-mono text-slate-500 font-bold">#{idx + 1}</span>
                        <div>
                          <div className="font-mono font-bold text-white text-base">{token.number}</div>
                          <div className="text-[10px] text-slate-400">{token.categoryName} • Issued {token.issuedAt}</div>
                        </div>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${PRIORITY_LEVELS[token.priority]?.badge}`}>
                        {token.priority}
                      </span>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-500 text-center py-8">No waiting customers in this queue.</p>
                )}
              </div>
            </div>

            {onHoldList.length > 0 && (
              <div className="mt-4 pt-4 border-t border-slate-700/60">
                <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider block mb-2">On Hold Queue ({onHoldList.length})</span>
                <div className="flex flex-wrap gap-2">
                  {onHoldList.map(t => (
                    <button
                      key={t.id}
                      onClick={() => handleResumeHeldToken(t.id)}
                      className="bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 px-2.5 py-1 rounded-lg text-xs font-mono flex items-center space-x-1 hover:bg-indigo-500/30"
                    >
                      <span>{t.number}</span>
                      <RotateCcw className="w-3 h-3 ml-1" />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderTVDisplay = () => {
    const activeCallingTokens = tokens.filter(t => t.status === TOKEN_STATUS.CALLING.id || t.status === TOKEN_STATUS.SERVING.id);
    const topWaitingTokens = tokens.filter(t => t.status === TOKEN_STATUS.WAITING.id).slice(0, 6);

    return (
      <div className="min-h-screen bg-slate-950 text-white p-8 flex flex-col justify-between">
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <div className="flex items-center space-x-4">
            <div className="bg-blue-600 p-3 rounded-2xl shadow-xl">
              <Building className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tight">{settings.businessName}</h1>
              <p className="text-sm text-slate-400">{settings.subtitle}</p>
            </div>
          </div>

          <div className="text-right">
            <div className="text-3xl font-mono font-bold text-blue-400">{currentTime.toLocaleTimeString()}</div>
            <div className="text-xs text-slate-400 uppercase tracking-widest mt-1">
              {currentTime.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 my-auto py-8">
          <div className="lg:col-span-8 space-y-4">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-400 block mb-2">NOW SERVING AT COUNTERS</span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {counters.filter(c => c.active).map(cnt => {
                const callingToken = tokens.find(t => t.counterId === cnt.id && (t.status === TOKEN_STATUS.CALLING.id || t.status === TOKEN_STATUS.SERVING.id));
                return (
                  <div
                    key={cnt.id}
                    className={`bg-slate-900/90 border-2 rounded-3xl p-6 shadow-2xl flex flex-col justify-between transition ${
                      callingToken ? 'border-emerald-500/80 shadow-emerald-500/10' : 'border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <span className="text-xl font-bold text-slate-200">{cnt.name}</span>
                      <span className="text-xs text-slate-500 font-mono">STATION #{cnt.number}</span>
                    </div>

                    <div className="my-6 text-center">
                      {callingToken ? (
                        <div>
                          <div className="text-6xl font-black font-mono text-emerald-400 tracking-tight animate-bounce">
                            {callingToken.number}
                          </div>
                          <div className="mt-2 text-xs text-slate-400 uppercase tracking-wider font-semibold">
                            {callingToken.categoryName}
                          </div>
                        </div>
                      ) : (
                        <div className="text-2xl font-bold text-slate-600 font-mono py-4">
                          AVAILABLE
                        </div>
                      )}
                    </div>

                    <div className="bg-slate-950/60 p-2 rounded-xl text-center text-xs text-slate-400">
                      {callingToken ? `Status: ${callingToken.status}` : 'Waiting for next ticket'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-4 bg-slate-900/60 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-amber-400 mb-4 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                UPCOMING TICKETS NEXT IN LINE
              </h3>

              <div className="space-y-3">
                {topWaitingTokens.length > 0 ? (
                  topWaitingTokens.map(token => (
                    <div
                      key={token.id}
                      className="bg-slate-950/80 border border-slate-800 p-4 rounded-2xl flex items-center justify-between"
                    >
                      <div>
                        <div className="text-2xl font-black font-mono text-white">{token.number}</div>
                        <div className="text-xs text-slate-400">{token.categoryName}</div>
                      </div>
                      <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${PRIORITY_LEVELS[token.priority]?.badge}`}>
                        {token.priority}
                      </span>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-500 py-8 text-center">Queue is empty.</p>
                )}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 text-center">
              <span className="text-xs text-slate-500">Thank you for your patience. Please keep your ticket ready.</span>
            </div>
          </div>
        </div>

        <div className="bg-blue-950/50 border border-blue-800/40 rounded-2xl px-6 py-3 flex items-center justify-between text-xs text-blue-200">
          <div className="flex items-center space-x-3">
            <span className="bg-blue-600 text-white font-bold px-2 py-0.5 rounded text-[10px] uppercase">NOTICE</span>
            <span>Welcome to {settings.businessName}. Please wait for audio callouts before approaching assigned counters.</span>
          </div>
          <button
            onClick={() => setActiveTab('DASHBOARD')}
            className="text-slate-400 hover:text-white text-xs underline"
          >
            Exit TV Screen
          </button>
        </div>
      </div>
    );
  };

  const renderTokenSearch = () => {
    const filteredTokens = tokens.filter(t => {
      const matchesSearch = 
        t.number.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.customerName && t.customerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (t.customerPhone && t.customerPhone.includes(searchQuery));
      const matchesStatus = statusFilter === 'ALL' || t.status === statusFilter;
      return matchesSearch && matchesStatus;
    });

    return (
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        <div className="bg-slate-800/60 border border-slate-700/60 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3 flex-1 min-w-[280px]">
            <Search className="w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by Token Number, Customer Name or Phone..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-white rounded-xl px-3.5 py-2 text-sm w-full focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center space-x-3">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none"
            >
              <option value="ALL">All Statuses</option>
              {Object.values(TOKEN_STATUS).map(s => (
                <option key={s.id} value={s.id}>{s.label}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900/80 text-slate-400 uppercase font-semibold border-b border-slate-700">
                <tr>
                  <th className="p-4">Token #</th>
                  <th className="p-4">Category</th>
                  <th className="p-4">Priority</th>
                  <th className="p-4">Customer</th>
                  <th className="p-4">Issued At</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {filteredTokens.length > 0 ? (
                  filteredTokens.map(token => (
                    <tr key={token.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-4 font-mono font-bold text-white text-sm">{token.number}</td>
                      <td className="p-4">{token.categoryName}</td>
                      <td className="p-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${PRIORITY_LEVELS[token.priority]?.badge}`}>
                          {token.priority}
                        </span>
                      </td>
                      <td className="p-4">
                        {token.customerName ? (
                          <div>
                            <div className="font-semibold text-slate-200">{token.customerName}</div>
                            <div className="text-[10px] text-slate-400">{token.customerPhone}</div>
                          </div>
                        ) : (
                          <span className="text-slate-500 italic">Walk-in</span>
                        )}
                      </td>
                      <td className="p-4 font-mono">{token.issuedAt}</td>
                      <td className="p-4">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${TOKEN_STATUS[token.status]?.color || 'bg-slate-700 text-slate-300'}`}>
                          {TOKEN_STATUS[token.status]?.label || token.status}
                        </span>
                      </td>
                      <td className="p-4 text-right space-x-2">
                        <button
                          onClick={() => {
                            setSelectedTokenForPrint(token);
                            setActiveTab('RECEPTION');
                          }}
                          className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg"
                          title="Print Ticket Preview"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        {token.status !== TOKEN_STATUS.CANCELLED.id && (
                          <button
                            onClick={() => handleCancelToken(token.id)}
                            className="p-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg"
                            title="Cancel Token"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-500">
                      No matching token records found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  const renderReports = () => (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-800/60 border border-slate-700/60 p-5 rounded-2xl">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-400" />
            Queue Performance & Operational Reports
          </h2>
          <p className="text-xs text-slate-400">Export offline CSV and JSON logs for audit and record keeping.</p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={exportTokensCSV}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-medium px-4 py-2 rounded-xl text-xs flex items-center space-x-2 transition"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV Report</span>
          </button>

          <button
            onClick={exportSystemJSON}
            className="bg-blue-600 hover:bg-blue-500 text-white font-medium px-4 py-2 rounded-xl text-xs flex items-center space-x-2 transition"
          >
            <Download className="w-4 h-4" />
            <span>Backup Full JSON Data</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-800/60 border border-slate-700/60 p-5 rounded-2xl shadow-sm">
          <h3 className="font-semibold text-white text-sm mb-4">Counter Serving Productivity</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={counterPerformanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
                <Legend />
                <Bar dataKey="completed" fill="#10b981" name="Completed" />
                <Bar dataKey="skipped" fill="#f59e0b" name="Skipped" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/60 p-5 rounded-2xl shadow-sm">
          <h3 className="font-semibold text-white text-sm mb-4">Queue Summary KPIs</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-700">
              <span className="text-xs text-slate-400">Total Issued</span>
              <div className="text-2xl font-bold text-white mt-1">{stats.total}</div>
            </div>
            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-700">
              <span className="text-xs text-slate-400">Completion Rate</span>
              <div className="text-2xl font-bold text-emerald-400 mt-1">
                {stats.total ? Math.round((stats.completed / stats.total) * 100) : 0}%
              </div>
            </div>
            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-700">
              <span className="text-xs text-slate-400">Avg Wait Time</span>
              <div className="text-2xl font-bold text-amber-400 mt-1">{stats.avgWait} mins</div>
            </div>
            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-700">
              <span className="text-xs text-slate-400">Avg Serve Time</span>
              <div className="text-2xl font-bold text-blue-400 mt-1">{stats.avgServe} mins</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-6 shadow-xl space-y-6">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-blue-400" />
            System & Organization Settings
          </h2>
          <p className="text-xs text-slate-400 mt-1">Configure business metadata, speech voice synthesizers, counters, and printer settings.</p>
        </div>

        <div className="space-y-4 pt-4 border-t border-slate-700/60">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Service Counter Management</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Add, edit, toggle online status, or remove counters.</p>
            </div>
            <button
              onClick={handleOpenAddCounterModal}
              className="bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition shadow"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Counter</span>
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {counters.map(cnt => (
              <div
                key={cnt.id}
                className="bg-slate-900/80 border border-slate-700/80 p-4 rounded-xl flex items-center justify-between flex-wrap gap-3"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${cnt.active ? 'bg-emerald-500' : 'bg-slate-600'}`}></div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-white text-sm">{cnt.name}</span>
                      <span className="text-[10px] font-mono bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700">
                        {cnt.id}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      Staff: <span className="text-slate-200">{cnt.staff || 'Unassigned'}</span> | Categories:{' '}
                      <span className="text-blue-400">
                        {cnt.categoryIds.length > 0 
                          ? categories.filter(c => cnt.categoryIds.includes(c.id)).map(c => c.name).join(', ') 
                          : 'All Services'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleToggleCounterActive(cnt.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition ${
                      cnt.active
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    {cnt.active ? 'Online' : 'Offline'}
                  </button>

                  <button
                    onClick={() => handleOpenEditCounterModal(cnt)}
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg transition"
                    title="Edit Counter"
                  >
                    <Edit className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleDeleteCounter(cnt.id)}
                    className="p-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded-lg transition"
                    title="Delete Counter"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4 pt-4 border-t border-slate-700/60">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Business Identity & Ticket Branding</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-slate-300 block mb-1">Business Name</label>
              <input
                type="text"
                value={settings.businessName}
                onChange={e => setSettings({ ...settings, businessName: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-300 block mb-1">Subtitle / Branch</label>
              <input
                type="text"
                value={settings.subtitle}
                onChange={e => setSettings({ ...settings, subtitle: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-300 block mb-1">Street Address</label>
              <input
                type="text"
                value={settings.address || ''}
                onChange={e => setSettings({ ...settings, address: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-300 block mb-1">Contact Phone</label>
              <input
                type="text"
                value={settings.phone}
                onChange={e => setSettings({ ...settings, phone: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
              />
            </div>
          </div>
        </div>

        <div className="space-y-4 pt-4 border-t border-slate-700/60">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Thermal Printer Options</h3>
          <label className="flex items-center space-x-3 bg-slate-900/60 p-3 rounded-xl border border-slate-700/60 cursor-pointer max-w-sm">
            <input
              type="checkbox"
              checked={settings.autoPrintOnIssue}
              onChange={e => setSettings({ ...settings, autoPrintOnIssue: e.target.checked })}
              className="rounded border-slate-700 text-blue-600 focus:ring-0"
            />
            <span className="text-xs font-medium text-slate-200">Automatically trigger Print window on Ticket creation</span>
          </label>
        </div>

        <div className="space-y-4 pt-4 border-t border-slate-700/60">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Voice Announcement Synthesizer</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <label className="flex items-center space-x-3 bg-slate-900/60 p-3 rounded-xl border border-slate-700/60 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.voiceEnabled}
                onChange={e => setSettings({ ...settings, voiceEnabled: e.target.checked })}
                className="rounded border-slate-700 text-blue-600 focus:ring-0"
              />
              <span className="text-xs font-medium text-slate-200">Enable Voice Callout</span>
            </label>

            <div>
              <label className="text-xs text-slate-300 block mb-1">Language Voice</label>
              <select
                value={settings.voiceLang}
                onChange={e => setSettings({ ...settings, voiceLang: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs focus:outline-none"
              >
                <option value="en-US">English (US)</option>
                <option value="en-GB">English (UK)</option>
                <option value="bn-BD">Bangla (bn-BD)</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-300 block mb-1">Voice Speed ({settings.voiceSpeed}x)</label>
              <input
                type="range"
                min="0.5"
                max="1.5"
                step="0.1"
                value={settings.voiceSpeed}
                onChange={e => setSettings({ ...settings, voiceSpeed: parseFloat(e.target.value) })}
                className="w-full accent-blue-500"
              />
            </div>
          </div>

          <button
            onClick={() => announceTokenVoice('A001', 'Counter 1', settings.voiceLang, settings.voiceSpeed, settings.voicePitch, false)}
            className="bg-slate-700 hover:bg-slate-600 text-white px-3 py-1.5 rounded-lg text-xs flex items-center space-x-2"
          >
            <Volume2 className="w-4 h-4" />
            <span>Test Voice Announcement</span>
          </button>
        </div>

        <div className="space-y-4 pt-4 border-t border-slate-700/60">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Data Management & Maintenance</h3>
          <div className="flex flex-wrap items-center gap-3">
            <label className="bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-xl text-xs font-medium cursor-pointer flex items-center space-x-2">
              <Upload className="w-4 h-4" />
              <span>Import Backup JSON</span>
              <input type="file" accept=".json" onChange={importSystemJSON} className="hidden" />
            </label>

            <button
              onClick={handleDailyReset}
              className="bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 px-4 py-2 rounded-xl text-xs font-medium flex items-center space-x-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset Daily Queue Data</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderShortcutModal = () => {
    if (!shortcutHelpOpen) return null;
    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 print:hidden">
        <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-blue-400" />
              Keyboard Shortcuts
            </h3>
            <button onClick={() => setShortcutHelpOpen(false)} className="text-slate-400 hover:text-white">
              <XCircle className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-2 text-xs">
            {[
              { key: 'F1', desc: 'Open Reception & Ticket Generation' },
              { key: 'F2', desc: 'Call Next Waiting Customer' },
              { key: 'F3', desc: 'Recall Active Token Voice Announcement' },
              { key: 'F4', desc: 'Skip Current Customer' },
              { key: 'F5', desc: 'Complete Current Customer' },
              { key: 'F11', desc: 'Toggle TV Display Fullscreen Screen' },
              { key: 'Ctrl + P', desc: 'Print Active Thermal Ticket Slip' },
              { key: 'Ctrl + F', desc: 'Quick Search Tokens' },
              { key: 'Ctrl + S', desc: 'Open System Settings' }
            ].map(item => (
              <div key={item.key} className="flex items-center justify-between py-1.5 border-b border-slate-800/60">
                <span className="font-mono bg-slate-800 text-blue-300 px-2 py-0.5 rounded border border-slate-700 font-bold">{item.key}</span>
                <span className="text-slate-300">{item.desc}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const renderToast = () => {
    if (!toastNotification) return null;
    return (
      <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-slate-700 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center space-x-3 animate-fade-in print:hidden">
        <Bell className="w-5 h-5 text-blue-400 animate-pulse" />
        <span className="text-xs font-medium">{toastNotification.message}</span>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-500 selection:text-white print:bg-white print:text-black">
      {/* Thermal Print Media CSS Rule Injection */}
      <style>{`
        @media print {
          body {
            background-color: white !important;
            color: black !important;
          }
          header, nav, button, input, select, .print\\:hidden {
            display: none !important;
          }
          #printable-ticket {
            display: block !important;
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 80mm !important;
            padding: 0 !important;
            margin: 0 !important;
            box-shadow: none !important;
            border: none !important;
          }
        }
      `}</style>

      {activeTab === 'TV_DISPLAY' ? (
        renderTVDisplay()
      ) : (
        <>
          {renderHeader()}
          {renderMobileNav()}

          <main className="flex-1 overflow-y-auto">
            {activeTab === 'DASHBOARD' && renderDashboard()}
            {activeTab === 'RECEPTION' && renderReception()}
            {activeTab === 'WORKSTATION' && renderWorkstation()}
            {activeTab === 'SEARCH' && renderTokenSearch()}
            {activeTab === 'REPORTS' && renderReports()}
            {activeTab === 'SETTINGS' && renderSettings()}
          </main>
        </>
      )}

      {renderShortcutModal()}
      {renderToast()}

      {/* Add / Edit Counter Modal */}
      {isCounterModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 print:hidden">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-400" />
                {editingCounter ? 'Edit Counter Details' : 'Add New Service Counter'}
              </h3>
              <button onClick={() => setIsCounterModalOpen(false)} className="text-slate-400 hover:text-white">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCounter} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 block mb-1 font-medium">Counter Display Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Counter 5 or VIP Desk"
                  value={counterForm.name}
                  onChange={e => setCounterForm({ ...counterForm, name: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-medium">Assigned Staff Member</label>
                <input
                  type="text"
                  placeholder="e.g. Jane Doe"
                  value={counterForm.staff}
                  onChange={e => setCounterForm({ ...counterForm, staff: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex items-center space-x-3 bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                <input
                  type="checkbox"
                  id="counterActiveToggle"
                  checked={counterForm.active}
                  onChange={e => setCounterForm({ ...counterForm, active: e.target.checked })}
                  className="rounded border-slate-700 text-blue-600 focus:ring-0 w-4 h-4 cursor-pointer"
                />
                <label htmlFor="counterActiveToggle" className="text-slate-200 font-medium cursor-pointer">
                  Counter Online / Active Status
                </label>
              </div>

              <div>
                <label className="text-slate-300 block mb-2 font-medium">Assignable Service Categories</label>
                <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                  {categories.map(cat => {
                    const isChecked = counterForm.categoryIds.includes(cat.id);
                    return (
                      <label
                        key={cat.id}
                        className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer transition ${
                          isChecked ? 'bg-blue-600/20 border-blue-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-400'
                        }`}
                      >
                        <div className="flex items-center space-x-2">
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: cat.color }}></span>
                          <span className="font-medium text-xs">{cat.name}</span>
                        </div>
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={e => {
                            const newCats = e.target.checked
                              ? [...counterForm.categoryIds, cat.id]
                              : counterForm.categoryIds.filter(id => id !== cat.id);
                            setCounterForm({ ...counterForm, categoryIds: newCats });
                          }}
                          className="rounded text-blue-600 border-slate-700"
                        />
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCounterModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 transition shadow-lg shadow-blue-600/25"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingCounter ? 'Save Changes' : 'Create Counter'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}